package aplicacion;

public class Departamento{
    private String nombre;
    private Director director;

    public Departamento(String nombre, Director director) {
        this.nombre = nombre;
        this.director = director;
    }
   
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Director getDirector() {
        return director;
    }

    public void setDirector(Director director) {
        this.director = director;
    }

}