package aplicacion;

import java.util.Scanner;

public class Usuario{
    Scanner sc = new Scanner(System.in);
    private String login;
    private String contrasena;
    private int clave;
    private String cif;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
    
    public int getClave() {
        return clave;
    }

    public void setClave(int clave) {
        this.clave = clave;
    }
    
    public void cifrado(){
        String abc = "abcdefghijklmnopqrstuvwxyz";
        for (int i = 0; i <= 26; i++){
        contrasena.charAt(i);
    }
    }
}